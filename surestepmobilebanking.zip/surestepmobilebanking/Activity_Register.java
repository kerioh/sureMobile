package com.kerioh.surestep.com.surestepmobilebanking;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.kerioh.surestep.com.surestepmobilebanking.utils.AppController;
import com.kerioh.surestep.com.surestepmobilebanking.utils.CustomJsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Admin on 5/20/2016.
 */
public class Activity_Register extends AppCompatActivity {
    private static final String POLICY_URL = "http://surestep.co.ke/index.php/about";
    private static final String URL = "http://62.12.113.67/mobile_app_api/android.php";

    public static final String KEY_USERNAME = "memberName";
    public static final String KEY_ACCOUNT_NO = "accountNumber";
    public static final String KEY_PHONE = "mobileNumber";
    public static final String KEY_EMAIL = "emailAddress";
    public static final String KEY_ID_NO = "nationalId";


    EditText mRegisrerName, mRegisterPNumber, mRegisterEmail, mRegisterAccount, mIdNumber;
    Button mRegister;
    TextView mUserPolicy;
    ProgressDialog progressDoalog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mRegisrerName = (EditText) findViewById(R.id.txtRegisterName);
        mRegisterPNumber = (EditText) findViewById(R.id.txtRegisterPhone);
        mRegisterEmail = (EditText) findViewById(R.id.txtRegisterMail);
        mRegisterAccount = (EditText) findViewById(R.id.txtAccountNumber);
        mIdNumber = (EditText) findViewById(R.id.txtUserId);
        mUserPolicy = (TextView) findViewById(R.id.lblTerms);
        mRegister = (Button) findViewById(R.id.btnRegister);


        mRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDoalog = new ProgressDialog(Activity_Register.this);
                progressDoalog.setMax(100);
                progressDoalog.setMessage("Creating Uer Account....");
                progressDoalog.setTitle("User Registration");
                progressDoalog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                progressDoalog.show();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            while (progressDoalog.getProgress() <= progressDoalog
                                    .getMax()) {
                                Thread.sleep(200);
                                handle.sendMessage(handle.obtainMessage());
                                if (progressDoalog.getProgress() == progressDoalog
                                        .getMax()) {
                                    progressDoalog.dismiss();
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }

            Handler handle = new Handler() {
                @Override
                public void handleMessage(Message msg) {
                    super.handleMessage(msg);
                    progressDoalog.incrementProgressBy(1);


                    final String memberName = mRegisrerName.getText().toString().trim();
                    final String accountNumber = mRegisterAccount.getText().toString().trim();
                    final String mobileNumber = mRegisterPNumber.getText().toString().trim();
                    final String emailAddress = mRegisterEmail.getText().toString().trim();
                    final String nationalId = mIdNumber.getText().toString().trim();
                    if (mRegisrerName.getText().toString().length() >= 1 && mRegisterAccount.getText().toString().length() >= 1
                            && mRegisterPNumber.getText().toString().length() >= 1
                            && mRegisterEmail.getText().toString().length() >= 1
                            && mIdNumber.getText().toString().length() >= 1) {

                        HashMap<String, String> params = new HashMap<>();
                        params.put(KEY_USERNAME, memberName);
                        params.put(KEY_ACCOUNT_NO, accountNumber);
                        params.put(KEY_PHONE, mobileNumber);
                        params.put(KEY_EMAIL, emailAddress);
                        params.put(KEY_ID_NO, nationalId);


                        CustomJsonObjectRequest request = new CustomJsonObjectRequest(Request.Method.POST, URL,
                                params, new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {

                                String responseData = "";

                                try {
                                    responseData = response.getString("response");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                Log.d("Response", responseData);

                                if (responseData.equalsIgnoreCase("The member was successfully registered")) {

                                    Intent intent = new Intent(getApplication(), MainActivity.class);
                                    startActivity(intent);

                                } else {
                                    Toast.makeText(Activity_Register.this, "Your account was created successfully,please check your email for log in details",
                                            Toast.LENGTH_LONG).show();
                                }
                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Intent intent = new Intent(getApplicationContext(), Activity_Check_Internet.class);
                                startActivity(intent);

                            }
                        });
                        AppController.getInstance().addToRequestQueue(request);


                    } else {
                        Toast.makeText(Activity_Register.this, "Please fill all fields",
                                Toast.LENGTH_SHORT).show();

                    }
                }
            };
        });


        mUserPolicy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW).setData(Uri.parse(POLICY_URL));
                startActivity(intent);
            }
        });


    }

    public void onPause() {
        super.onPause();
        mRegisrerName.setText("");
        mRegisterAccount.setText("");
        mUserPolicy.setText("");
        mRegisterEmail.setText("");
        mIdNumber.setText("");
    }
}


