package com.kerioh.surestep.com.surestepmobilebanking;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.kerioh.surestep.com.surestepmobilebanking.adapter.CustomList;

/**
 * Created by Admin on 5/24/2016.
 */
public class Activity_PayBills extends Activity {
    ListView list;
    String[] web = {
            "Kenya Power Tokens",
            "Kenya Power Post-Paid",
            "DSTV Bills",

    };
    Integer[] imageId = {
            R.drawable.kplc,
            R.drawable.kplc,
            R.drawable.dstv,


    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listview_paybill);

        CustomList adapter = new
                CustomList(Activity_PayBills.this, web, imageId);
        list = (ListView) findViewById(R.id.list);
        list.setAdapter(adapter);


        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure want to select this option ?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialog, final int id) {
                Intent intent= new Intent(Activity_PayBills.this,Activity_PayBill.class);
                startActivity(intent);
            }
        })
                .setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        //disable click
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        //cancel click
                    }
                });


        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                AlertDialog alertDialog = builder.create();
                alertDialog.show();

            }
        });

    }

}
