package com.kerioh.surestep.com.surestepmobilebanking;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by Admin on 5/31/2016.
 */
public class Activity_Services extends AppCompatActivity {
    TextView mWithdraw,mDeposit,mCheckBalance,mTransfer,mPayBills,mLoanRequest,mAirtime,mLoanCalc,mLocator;
    public static final String KEY_MEMBER_ACCOUNT_NUMBER = "memberNumber";
    public static final String KEY_MEMBER_PASSWORD = "memberPassword";
    String memberNumber;
    String memberPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_services);

        mWithdraw=(TextView)findViewById(R.id.btnWithdrawCash);
        mDeposit=(TextView)findViewById(R.id.btnDepositCash);
        mCheckBalance=(TextView)findViewById(R.id.btnCheckBalance);
        mTransfer=(TextView)findViewById(R.id.btnFundsTransfer);
        mPayBills=(TextView)findViewById(R.id.btnPayBills);
        mLoanRequest=(TextView)findViewById(R.id.btnLoanRequest);
        mAirtime=(TextView)findViewById(R.id.btnAirTimePurchase);
        mLoanCalc=(TextView)findViewById(R.id.btnLoanCalculator);
        mLocator=(TextView)findViewById(R.id.btnLocator);

        Bundle mBundle= getIntent().getExtras();
         memberNumber=mBundle.getString("memberNumber");
         memberPassword=mBundle.getString("memberPassword");

        mWithdraw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Activity_Withdraw.class);
                startActivity(intent);
            }
        });
        mDeposit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Activity_Deposit.class);
                startActivity(intent);
            }
        });
        mCheckBalance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Activity_CheckBalance.class);
                Bundle mBundle = new Bundle();
                mBundle.putString(KEY_MEMBER_ACCOUNT_NUMBER, memberNumber);
                mBundle.putString(KEY_MEMBER_PASSWORD, memberPassword);
                intent.putExtras(mBundle);
                startActivity(intent);
            }
        });
        mPayBills.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Activity_PayBills.class);
                startActivity(intent);
            }
        });
        mLoanRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Activity_Loans.class);
                Bundle mBundle = new Bundle();
                mBundle.putString(KEY_MEMBER_ACCOUNT_NUMBER, memberNumber);
                mBundle.putString(KEY_MEMBER_PASSWORD, memberPassword);
                intent.putExtras(mBundle);
                startActivity(intent);
            }
        });
        mTransfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Activity_Transfer.class);
                startActivity(intent);
            }
        });
        mAirtime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Activity_Airtime_Recipient.class);
                Bundle mBundle = new Bundle();
                mBundle.putString(KEY_MEMBER_ACCOUNT_NUMBER, memberNumber);
                mBundle.putString(KEY_MEMBER_PASSWORD, memberPassword);
                intent.putExtras(mBundle);
                startActivity(intent);
            }
        });
        mLoanCalc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Activity_Loan_Calculator.class);
                startActivity(intent);
            }
        });
        mLocator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Activity_Locator.class);
                startActivity(intent);
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            //change Password
            case R.id.menuChangePassword:
                Intent intent = new Intent(this, Activity_change_pin.class);
                Bundle mBundle = new Bundle();
                mBundle.putString(KEY_MEMBER_ACCOUNT_NUMBER, memberNumber);
                mBundle.putString(KEY_MEMBER_PASSWORD, memberPassword);
                intent.putExtras(mBundle);
                this.startActivity(intent);
            //settings
            case R.id.action_settings:
                startActivityForResult(new Intent(android.provider.Settings.ACTION_SETTINGS), 0);
                return true;

            case R.id.menuShare:
                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                String shareBody = "Hey there,your friend wants you to try this app";
                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject Here");
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                startActivity(Intent.createChooser(sharingIntent, "Share via"));


            default:
                return super.onOptionsItemSelected(item);
        }
    }


}
