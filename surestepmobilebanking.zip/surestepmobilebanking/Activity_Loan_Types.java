package com.kerioh.surestep.com.surestepmobilebanking;

import android.app.Activity;
import android.os.Bundle;

public class Activity_Loan_Types extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity__loan__types);
    }
}
