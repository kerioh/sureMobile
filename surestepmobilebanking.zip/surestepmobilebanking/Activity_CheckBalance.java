package com.kerioh.surestep.com.surestepmobilebanking;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.kerioh.surestep.com.surestepmobilebanking.utils.AppController;
import com.kerioh.surestep.com.surestepmobilebanking.utils.CustomJsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;

/**
 * Created by Admin on 5/31/2016.
 */
public class Activity_CheckBalance extends AppCompatActivity {
    //String balance, shares, retainer, interest;
    final String URL = "http://62.12.113.67/mobile_app_api/android.php?type=0409";
    private static final String TAG_MEMBER_NUMBER = "memberNumber";
    private static final String TAG_MEMBER_PASSWORD = "memberPassword";
    public static final String TAG_AMOUNT = "ammount";
    public static final String TAG_INSTALLMENTS = "installments";



    private static final String TAG_BALANCE = "outstanding Balance";
    private static final String TAG_SHARES = "current Shares";
    private static final String TAG_RETAINER = "Shares Retained";
    private static final String TAG_INTEREST = "outstanding intrest";


    TextView moutstandingBal, mcurrentShares, mretainedShares, moutstandingInterest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_balance);
        moutstandingBal = (TextView) findViewById(R.id.tvoutstandingBal);
        mcurrentShares = (TextView) findViewById(R.id.tvcurrentShares);
        mretainedShares = (TextView) findViewById(R.id.tvretainedShares);
        moutstandingInterest = (TextView) findViewById(R.id.tvinterestOutstanding);
//receive bundle here
        Bundle mBundle= getIntent().getExtras();
        final String member_Number = mBundle.getString("memberNumber");
        final String member_Password = mBundle.getString("memberPassword");


        HashMap<String, String> params = new HashMap<>();
        params.put(TAG_MEMBER_NUMBER, member_Number);
        params.put(TAG_MEMBER_PASSWORD, member_Password);
        params.put(TAG_AMOUNT, "50000");
        params.put(TAG_INSTALLMENTS, "2");


        CustomJsonObjectRequest request = new CustomJsonObjectRequest(Request.Method.POST, URL,
                params, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                String responseData = "";

                Toast.makeText(Activity_CheckBalance.this, member_Number + member_Password,
                        Toast.LENGTH_LONG).show();

                try {
                    String balance = response.getString(TAG_BALANCE);
                    String shares = response.getString(TAG_SHARES);
                    String retainer = response.getString(TAG_RETAINER);
                    String interest = response.getString(TAG_INTEREST);


                    moutstandingBal.setText(balance);
                    mcurrentShares.setText(shares);
                    mretainedShares.setText(retainer);
                    moutstandingInterest.setText(interest);
                    responseData = response.getString("response");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Log.d("Response", response.toString());


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // Log.d("Error", error.toString());
                Intent intent = new Intent(getApplicationContext(), Activity_Check_Internet.class);
                startActivity(intent);
            }
        });
        AppController.getInstance().addToRequestQueue(request);
    }
}

