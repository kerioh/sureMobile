package com.kerioh.surestep.com.surestepmobilebanking;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;
import com.kerioh.surestep.com.surestepmobilebanking.adapter.User;
import com.kerioh.surestep.com.surestepmobilebanking.adapter.UserAdapter;
import com.kerioh.surestep.com.surestepmobilebanking.utils.AppController;
import com.kerioh.surestep.com.surestepmobilebanking.utils.CustomJsonObjectRequest;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Admin on 6/9/2016.
 */
public class Activity_Apply_Loan extends AppCompatActivity {
    private static final String URL = "http://62.12.113.67/mobile_app_api/android.php?type=0409";
    public static final String KEY_QUESTIONNAIRES = "http://62.12.113.67/mobile_app_api/loanDescriptions.php?";
    private static final String TAG_LIMIT = "Qualifies";
    String qualifyingAmmount="";
    private static final String TAG_CLIENT_NAME = "memberName";
    EditText mloanDuration, mLoanAmount;
    Button mLoanRequest;
    TextView mloanLimit;
    private String m_Text = "";
    private static final String TAG_MEMBER_NUMBER = "memberNumber";
    public static final String TAG_PASSWORD = "memberPassword";
    // private static final String TAG_ACCOUNT_NUMBER = "accountNumber";
    public static final String TAG_AMOUNT = "ammount";
    public static final String TAG_INSTALLMENTS = "installments";
    String member_Number;
    String member_pass;

    //public static final String TAG_ID = "id";
    private static final String TAG_STUDY_TITLE = "Product Description";
    String mUserId, deviceId;

    ArrayList<User> mData;
    UserAdapter mAdapter;

    TextView mTitle, mStudyType, mStudyState, mStudyDate;
    Button mStartstudy;
    Spinner mStudy;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apply_loan);
        mLoanRequest = (Button) findViewById(R.id.btnRequestLoan);
        mloanLimit = (TextView) findViewById(R.id.tvLoanLimit);
        mloanDuration = (EditText) findViewById(R.id.txtLoanDuration);
        mLoanAmount = (EditText) findViewById(R.id.txtLoanRequestAmount);
        mLoanAmount.addTextChangedListener(new TextWatcher() {



            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(!mLoanAmount.getText().toString().equals("")) {
                    int ammount=0;
                    try{
                    ammount = Integer.parseInt(mLoanAmount.getText().toString());
                }catch(NumberFormatException e) {
                        Toast.makeText(Activity_Apply_Loan.this, "You do no qualify for that amount!",
                                Toast.LENGTH_LONG).show();
                }
                    int limit = Integer.parseInt(qualifyingAmmount);
                    if (ammount <= limit) {
                        Toast.makeText(Activity_Apply_Loan.this, "You are good to go",
                                Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(Activity_Apply_Loan.this, "You do no qualify for that amount!",
                                Toast.LENGTH_LONG).show();
                    }
                }

//compare the amount entered with loan limit
                //if amount entered is less or equal to loan limit then allow loan
                //else, set error as request exceeds set loan limit.

            }
        });
        mloanDuration.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
//compare the duration selected with loan duration limit
                //if duration is less or equal to loan limit then allow
                //else, set error as selected duration exceeds set loan duration limit

            }
        });

        Bundle mBundle = getIntent().getExtras();
        member_Number = mBundle.getString("memberNumber");
        member_pass = mBundle.getString("memberPassword");


        mTitle = (TextView) findViewById(R.id.tvSelectStudy);
        mStudy = (Spinner) findViewById(R.id.spnLoanType);


        mData = new ArrayList<>();

        getStudyUser();


        mStudy.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                User user = (User) parent.getItemAtPosition(position);

                mUserId = user.getId();

                //Log.d("User id", mUserId);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        Toast.makeText(Activity_Apply_Loan.this, member_Number + member_pass,
                Toast.LENGTH_LONG).show();

       /* HashMap<String, String> params = new HashMap<>();
        params.put(TAG_LIMIT, mloanLimit.getText().toString());
        params.put(TAG_INSTALLMENTS, mloanDuration.getText().toString());
        params.put(TAG_AMOUNT, mLoanAmount.getText().toString());*/

        HashMap<String, String> params = new HashMap<>();
        params.put(TAG_MEMBER_NUMBER, member_Number);
        params.put(TAG_PASSWORD, member_pass);
        params.put(TAG_AMOUNT, "50000");
        params.put(TAG_INSTALLMENTS, "2");


        CustomJsonObjectRequest request = new CustomJsonObjectRequest(Request.Method.POST, URL,
                params, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                String responseData = "";

                try {
                    responseData = response.getString("login");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Log.d("RESPONSE", response.toString());
                if (responseData.equalsIgnoreCase("successful")) {
                    try {
                        qualifyingAmmount=response.getString(TAG_LIMIT);
                        mloanLimit.setText("Dear " + response.getString(TAG_CLIENT_NAME) +
                                " your loan limit is Kshs: " + response.getString(TAG_LIMIT));
                    } catch (Exception e) {
                    }
                } else {
                    Toast.makeText(Activity_Apply_Loan.this, "Client does not exist",
                            Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // Log.d("Error", error.toString());
                Intent intent = new Intent(getApplicationContext(), Activity_Check_Internet.class);
                startActivity(intent);
            }
        });
        AppController.getInstance().addToRequestQueue(request);
    }


//get loan type
    private void getStudyUser() {
        CustomJsonObjectRequest userRequest = new CustomJsonObjectRequest(Request.Method.GET, KEY_QUESTIONNAIRES,
                null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {

                Log.d("response", jsonObject.toString());

                try {
                    JSONArray response = jsonObject.getJSONArray("success");

                    for (int i = 0; i < response.length(); i++) {

                        JSONObject studyObj = response.getJSONObject(i);
                        // Log.d("Question", studyObj.toString());

                       // String userId = studyObj.getString(TAG_ID);
                        String userName = studyObj.getString(TAG_STUDY_TITLE);

                        User user = new User();
                      //  user.setId(userId);
                        user.setUserName(userName);

                        mData.add(user);

                        mAdapter = new UserAdapter(Activity_Apply_Loan.this, android.R.layout.simple_spinner_item, mData);
                        mStudy.setAdapter(mAdapter);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {

            }
        });
        AppController.getInstance().addToRequestQueue(userRequest);


        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you  want to apply for Ksh :" + m_Text + " ?");
        final EditText input = new EditText(this);


        input.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setHint("ENTER PASSWORD");
        input.setGravity(Gravity.CENTER_HORIZONTAL);

        builder.setView(input);


        builder.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialog, final int id) {
                //disable click

                dialog.cancel();
            }
        })
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        //update click
                        m_Text = input.getText().toString();
                        //confirm that text matches user password
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        //cancel click
                        dialog.dismiss();
                    }
                });


        mLoanRequest.setOnClickListener(new View.OnClickListener()

                                        {
                                            @Override
                                            public void onClick(View v) {

//check loan amount limit
                                                //check loan duration limit
                                                //update relevant tables
                                                //transfer amount to m-pesa
                                                //notify user
                                                //home.


                                                AlertDialog alertDialog = builder.create();
                                                alertDialog.show();
                                            }
                                        }

        );

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "Activity_Apply_Loan Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse("android-app://com.kerioh.surestep.com.surestepmobilebanking/http/host/path")
        );
        AppIndex.AppIndexApi.start(client, viewAction);
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "Activity_Apply_Loan Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse("android-app://com.kerioh.surestep.com.surestepmobilebanking/http/host/path")
        );
        AppIndex.AppIndexApi.end(client, viewAction);
        client.disconnect();
    }




}








