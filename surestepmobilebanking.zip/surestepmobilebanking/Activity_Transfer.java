package com.kerioh.surestep.com.surestepmobilebanking;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by Admin on 5/24/2016.
 */
public class Activity_Transfer extends AppCompatActivity {
    Button mOwnAccount,mOtherShirikaAccount,mOtherBankAccount,mMpesaAccount;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transfer);
        mOwnAccount=(Button)findViewById(R.id.btnTransferOwnAcc);
        mOtherShirikaAccount=(Button)findViewById(R.id.btnTransferOtherInternalAcc);
        mOtherBankAccount=(Button)findViewById(R.id.btnTransferOtherBankAcc);
        mMpesaAccount=(Button)findViewById(R.id.btnTransferMpesa);



        mOwnAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Activity_Own_Acc_Transfer.class);
                startActivity(intent);
            }
        });
        mOtherShirikaAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Activity_Other_Internal_Acc_Transfer.class);
                startActivity(intent);
            }
        });
        mOtherBankAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Activity_Other_Bank_Acc_Transfer.class);
                startActivity(intent);
            }
        });
        mMpesaAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Activity_mpesa.class);
                startActivity(intent);
            }
        });
    }
}
