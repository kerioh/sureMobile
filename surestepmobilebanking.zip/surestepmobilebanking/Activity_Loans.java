package com.kerioh.surestep.com.surestepmobilebanking;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

/**
 * Created by Admin on 6/2/2016.
 */
public class Activity_Loans extends AppCompatActivity {
    Button mLoanApplication,mRepayment,mStatus,mLoanBalances;
    public static final String KEY_MEMBER_ACCOUNT_NUMBER = "memberNumber";
    public static final String KEY_PASSWORD = "memberPassword";
    String member_Number;
    String member_pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loans);
        mLoanApplication=(Button)findViewById(R.id.btnLoanApplication);
        mRepayment=(Button)findViewById(R.id.btnLoanRepayment);
        mStatus=(Button)findViewById(R.id.btnLoanStatus);
        mLoanBalances=(Button)findViewById(R.id.btnLoanBalances);
        Bundle mBundle= getIntent().getExtras();
        member_Number = mBundle.getString("memberNumber");
        member_pass = mBundle.getString("memberPassword");




        mLoanApplication.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(getApplicationContext(),Activity_Apply_Loan.class);
                Bundle mBundle = new Bundle();
                mBundle.putString(KEY_MEMBER_ACCOUNT_NUMBER, member_Number);
                mBundle.putString(KEY_PASSWORD, member_pass);
                intent.putExtras(mBundle);
                startActivity(intent);
            }
        });
        mRepayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        mStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        mLoanBalances.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
}
