package com.kerioh.surestep.com.surestepmobilebanking;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by Admin on 5/23/2016.
 */
public class Activity_Deposit extends AppCompatActivity {

    Button mOwnAccountDeposit,mOtherAccountDeposit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deposits);
        mOwnAccountDeposit=(Button)findViewById(R.id.btnDepositOwnAccount);
        mOtherAccountDeposit=(Button)findViewById(R.id.btnDepositOtherAccount);
        mOwnAccountDeposit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Activity_Deposit_Own_Acc.class);
                startActivity(intent);
            }
        });
        mOtherAccountDeposit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Activity_Deposit_Other_Acc.class);
                startActivity(intent);
            }
        });
    }

}
