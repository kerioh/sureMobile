package com.kerioh.surestep.com.surestepmobilebanking.adapter;

/**
 * Created by Admin on 7/14/2016.
 */
public class User {
    private String mId;
    private String mUserName;

    public User() {
    }

    public User(String userName) {
        mUserName = userName;
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getUserName() {
        return mUserName;
    }

    public void setUserName(String userName) {
        mUserName = userName;
    }

    public String toString(){
        return mUserName;
    }
}
