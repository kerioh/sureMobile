package com.kerioh.surestep.com.surestepmobilebanking.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


import com.kerioh.surestep.com.surestepmobilebanking.R;
import com.kerioh.surestep.com.surestepmobilebanking.model.Calculator;

import java.util.List;

/**
 * Created by G on 4/19/2016.
 */
public class LoanCalculatorAdapter extends BaseAdapter {
    Activity mActivity;
    List<Calculator> mList;

    public LoanCalculatorAdapter(Activity activity, List<Calculator> list) {
        mActivity = activity;
        mList = list;
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return mList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView = convertView;

        if (rowView == null){
            LayoutInflater inflater = (LayoutInflater) mActivity
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            rowView = inflater.inflate(R.layout.loan_calculator_listitem, parent, false);

            ViewHolder viewHolder = new ViewHolder();

            viewHolder.contactName = (TextView) rowView.findViewById(R.id.lblContribution);
            viewHolder.contactNumber = (TextView) rowView.findViewById(R.id.txtLoanFigure);


            rowView.setTag(viewHolder);

        }

        ViewHolder vHolder = (ViewHolder) rowView.getTag();
        Calculator calculator = mList.get(position);

        vHolder.contactName.setText(calculator.getAmount());
        vHolder.contactNumber.setText(calculator.getLoanFigure());


        return rowView;

    }

    class ViewHolder{
        TextView contactName;
        TextView contactNumber;

    }
}
