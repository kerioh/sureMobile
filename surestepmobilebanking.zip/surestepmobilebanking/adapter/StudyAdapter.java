package com.kerioh.surestep.com.surestepmobilebanking.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.kerioh.surestep.com.surestepmobilebanking.R;

import java.util.ArrayList;

/**
 * Created by G on 15/12/2015.
 */
public class StudyAdapter extends ArrayAdapter<Model_study> {

    Activity mActivity;
    ArrayList<Model_study> mData = null;

    public StudyAdapter(Activity activity, int resource, ArrayList<Model_study> data){
        super(activity, resource, data);

        mActivity = activity;
        mData = data;

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return super.getView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        View rowView = convertView;

        if (rowView == null){
            LayoutInflater inflater = mActivity.getLayoutInflater();

            rowView = inflater.inflate(R.layout.spinner_dropdown_item, parent, false);

        }

        Model_study study = mData.get(position);

        if (study != null){
            TextView studyName = (TextView) rowView.findViewById(R.id.tvSpinnerItem);

            if (studyName != null){
                studyName.setText(study.getValue());
            }

        }
        return rowView;
    }
}
