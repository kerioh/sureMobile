package com.kerioh.surestep.com.surestepmobilebanking.adapter;

/**
 * Created by Admin on 7/14/2016.
 */
public class Model_study {
    private String mId;
    private String mName;
    public Model_study() {
    }

    public Model_study(String name) {
        mName = name;
    }

    public String getId() {
        return mId;
    }
    public void setId(String id) {
        mId = id;
    }
    public String getValue() {
        return mName;
    }

    public void setValue(String name) {
        mName = name;
    }
    public String toString(){
        return mName;
    }
}
