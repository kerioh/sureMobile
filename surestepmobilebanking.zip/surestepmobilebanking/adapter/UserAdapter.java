package com.kerioh.surestep.com.surestepmobilebanking.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;


import com.kerioh.surestep.com.surestepmobilebanking.R;

import java.util.ArrayList;

/**
 * Created by G on 1/26/2016.
 */
public class UserAdapter extends ArrayAdapter<User> {
    Activity mActivity;
    ArrayList<User> mData=null;

    public UserAdapter(Activity activity, int resource, ArrayList<User> data){
        super(activity, resource, data);
        mActivity = activity;
        mData = data;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return super.getView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        View rowView = convertView;

        if (rowView == null) {

            LayoutInflater inflater = mActivity.getLayoutInflater();

            rowView = inflater.inflate(R.layout.spinner_dropdown_item, parent, false);

        }

        User user = mData.get(position);

        if (user != null){
            TextView userName = (TextView) rowView.findViewById(R.id.tvSpinnerItem);

            if (userName != null) {

                userName.setText(user.getUserName());

            }

        }
        return rowView;
    }
}
