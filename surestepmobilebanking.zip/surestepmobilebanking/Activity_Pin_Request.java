package com.kerioh.surestep.com.surestepmobilebanking;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.kerioh.surestep.com.surestepmobilebanking.utils.AppController;
import com.kerioh.surestep.com.surestepmobilebanking.utils.CustomJsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

/**
 * Created by Admin on 6/15/2016.
 */
public class Activity_Pin_Request extends AppCompatActivity {
    private static final String URL = "http://62.12.113.67/mobile_app_api/loan_from_app.php";
    private static final String TAG_CLIENT_NAME = "memberName";
    private static final String TAG_MEMBER_NUMBER = "memberNumber";
    String memberNumber="";
    TextView mPinRequest;
    EditText mCustomerPin;
    Button mPinAccept, mPinCancel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin_request);

        mPinRequest = (TextView) findViewById(R.id.tvPinRequest);
        mCustomerPin = (EditText) findViewById(R.id.txtPinRequest);
        mPinAccept = (Button) findViewById(R.id.btnPinAccept);
        mPinCancel = (Button) findViewById(R.id.btnPinCancel);

        Bundle mBundle= getIntent().getExtras();
        memberNumber = mBundle.getString("memberNumber");

        HashMap<String, String> params = new HashMap<>();
        params.put(TAG_MEMBER_NUMBER, memberNumber);

        CustomJsonObjectRequest request = new CustomJsonObjectRequest(Request.Method.POST, URL,
                params, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {


                try {

                    String clientname = response.getString(TAG_CLIENT_NAME);



                    mPinRequest.setText("Dear " + clientname + ", please enter your pin tp proceed with this transaction ");
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // Log.d("Error", error.toString());
                Intent intent = new Intent(getApplicationContext(), Activity_Check_Internet.class);
                startActivity(intent);
            }
        });
        AppController.getInstance().addToRequestQueue(request);

        mPinAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //confirm the pin entred is same as log in pin.
            }
        });
        mPinCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
            }
        });
    }

}
