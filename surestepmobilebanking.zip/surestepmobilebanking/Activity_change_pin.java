package com.kerioh.surestep.com.surestepmobilebanking;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;

import com.kerioh.surestep.com.surestepmobilebanking.utils.AppController;
import com.kerioh.surestep.com.surestepmobilebanking.utils.CustomJsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;


/**
 * Created by Admin on 6/20/2016.
 */
public class Activity_change_pin extends AppCompatActivity {

    public static final String KEY_MEMBER_ACCOUNT_NUMBER = "memberNumber";
    public static final String KEY_MEMBER_PASSWORD = "memberPassword";
    public static final String KEY_CURRENT = "oldPin";
    public static final String KEY_NEW_PIN = "newPin";
    public static final String KEY_CONFIRM = "confirmNewPin";
    private static final String URL = "http://62.12.113.67/mobile_app_api/android.php?type=0447";
    EditText mCurrentPin, mNewPin, mConfirmNewPin;
    Button mSubmitChanges;
    String member_Number;
    String member_pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_change_pin);

        mCurrentPin = (EditText) findViewById(R.id.txtCurrentPin);
        mNewPin = (EditText) findViewById(R.id.txtNewPin);
        mConfirmNewPin = (EditText) findViewById(R.id.txtConfirmPin);

        mSubmitChanges = (Button) findViewById(R.id.btnChangePin);


        Bundle mBundle = getIntent().getExtras();
        member_Number = mBundle.getString("memberNumber");
        member_pass = mBundle.getString("memberPassword");

        Toast.makeText(Activity_change_pin.this, member_Number + member_pass,
                Toast.LENGTH_LONG).show();


        mSubmitChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mNewPin.getText().toString().equals(mConfirmNewPin.getText().toString())) {

                    HashMap<String, String> params = new HashMap<>();
                    params.put(KEY_MEMBER_ACCOUNT_NUMBER, member_Number);
                    params.put(KEY_MEMBER_PASSWORD, member_pass);
                    params.put(KEY_CURRENT, mCurrentPin.getText().toString());
                    params.put(KEY_NEW_PIN, mNewPin.getText().toString());
                    params.put(KEY_CONFIRM, mConfirmNewPin.getText().toString());


                    CustomJsonObjectRequest request = new CustomJsonObjectRequest(Request.Method.POST, URL,
                            params, new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            String responseData = "";

                            try {
                                responseData = response.getString("update");
                                Log.d("RESPONSE", response.toString());
                                if (responseData.equalsIgnoreCase("Your pin was successfully updated")) {

                                    Log.d("RESPONSE", response.toString());

                                    Toast.makeText(Activity_change_pin.this, "Password changed Successfully",
                                            Toast.LENGTH_LONG).show();
                                } else {
                                    Toast.makeText(Activity_change_pin.this, "User name or Password does not exist",
                                            Toast.LENGTH_LONG).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // Log.d("Error", error.toString());
                            Intent intent = new Intent(getApplicationContext(), Activity_Check_Internet.class);
                            startActivity(intent);
                        }
                    });

                    AppController.getInstance().addToRequestQueue(request);
                } else {
                    Toast.makeText(Activity_change_pin.this, "Passwords do not match",
                            Toast.LENGTH_LONG).show();
                }

            }
        });

    }
}
