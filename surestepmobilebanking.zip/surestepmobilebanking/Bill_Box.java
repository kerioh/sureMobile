package com.kerioh.surestep.com.surestepmobilebanking;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Admin on 5/24/2016.
 */
public class Bill_Box extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listview_paybill);
    }
}
