package com.kerioh.surestep.com.surestepmobilebanking;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.kerioh.surestep.com.surestepmobilebanking.utils.AppController;
import com.kerioh.surestep.com.surestepmobilebanking.utils.CustomJsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static android.widget.Toast.LENGTH_LONG;

public class MainActivity extends AppCompatActivity {
    public static final String KEY_HAS_LOGGED_IN = "is_previously_started";
    public static final String KEY_PASSWORD = "password";
    public static final String KEY_MEMBER_ACCOUNT_NUMBER = "account_number";
   // private static final String URL = "http://62.12.113.67/mobile_app_api/login_from_app.php";
    private static final String URL2 = "http://62.12.113.67/mobile_app_api/android.php?type=0409";
    public static final String KEY_PASSWORD2 = "memberPassword";
    public static final String KEY_MEMBER_ACCOUNT_NUMBER2 = "memberNumber";
    EditText mMemberNumber, mMemberPassword;
    Button logIn, register;
    SharedPreferences mPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mPreferences = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
        boolean hasLoggedIn = mPreferences.getBoolean(MainActivity.KEY_HAS_LOGGED_IN, false);
        if (hasLoggedIn) {
            Intent intent = new Intent(getApplicationContext(), Activity_Services.class);

            intent.putExtra(KEY_PASSWORD2, mPreferences.getString(KEY_PASSWORD2, ""));
            intent.putExtra(KEY_MEMBER_ACCOUNT_NUMBER2, mPreferences.getString(KEY_MEMBER_ACCOUNT_NUMBER2, ""));

            startActivity(intent);
        }


        mMemberNumber = (EditText) findViewById(R.id.txtmemberNumber);
        mMemberPassword = (EditText) findViewById(R.id.txtmemberPassword);
        mMemberNumber.setText("UPS00015");
        mMemberPassword.setText("14428905");
        logIn = (Button) findViewById(R.id.btnLogin);
        register = (Button) findViewById(R.id.btnRegister);

        logIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mMemberNumber.getText().toString().length() >= 4 || mMemberPassword.getText().toString().length() >= 4) {

                    HashMap<String, String> params = new HashMap<>();
                    params.put(KEY_MEMBER_ACCOUNT_NUMBER2, mMemberNumber.getText().toString());
                    params.put(KEY_PASSWORD2, mMemberPassword.getText().toString());


                    CustomJsonObjectRequest request = new CustomJsonObjectRequest(Request.Method.POST, URL2,
                            params, new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            String responseData = "";

                            try {
                                responseData = response.getString("login");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            if (responseData.equalsIgnoreCase("successful")) {

                                //startActivity(new Intent(MainActivity.this, Activity_Services.class));
                                Log.d("RESPONSE",response.toString());
                                Intent intent = new Intent(getApplication(), Activity_Services.class);
                                Bundle mBundle = new Bundle();
                                mBundle.putString(KEY_MEMBER_ACCOUNT_NUMBER2, mMemberNumber.getText().toString());
                                mBundle.putString(KEY_PASSWORD2, mMemberPassword.getText().toString());

                                intent.putExtras(mBundle);
                                startActivity(intent);

                            } else {
                                Toast.makeText(MainActivity.this, "User name or Password does not exist",
                                        Toast.LENGTH_LONG).show();
                            }
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Intent intent = new Intent(getApplicationContext(), Activity_Check_Internet.class);
                            startActivity(intent);
                            // Log.d("Error", error.toString());
                           /* Toast.makeText(MainActivity.this, "Check your internet connection !",
                                    Toast.LENGTH_LONG).show();*/
                        }
                    });
                    AppController.getInstance().addToRequestQueue(request);


                } else {
                    Toast.makeText(MainActivity.this, "Member number and Password must be at least 4 characters",
                            Toast.LENGTH_LONG).show();
                }
            }
        });


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Activity_Register.class);
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_notifications, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {
            //settings
            case R.id.menuEnableNotifications:
                return true;
            //change Password
            case R.id.menuDisableNotifications:


            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void onPause() {
        super.onPause();
        mMemberNumber.setText("");
        mMemberPassword.setText("");
    }

}
