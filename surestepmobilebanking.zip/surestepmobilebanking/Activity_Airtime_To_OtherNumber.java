package com.kerioh.surestep.com.surestepmobilebanking;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

/**
 * Created by Admin on 5/24/2016.
 */
public class Activity_Airtime_To_OtherNumber extends AppCompatActivity {
    public static final String KEY_MEMBER_ACCOUNT_NUMBER = "memberNumber";
    String memberNumber;
    Spinner mSelectOperator;
    TextView mUserAccount;
    EditText mRecipientNumber,mAirtimeAmount;
    Button mOtherNumberSubmit,mOtherNumberCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otherairtime_recipient);
        mSelectOperator=(Spinner)findViewById(R.id.spnOptions);
        mUserAccount=(TextView)findViewById(R.id.lblUserAccNo);
        mRecipientNumber=(EditText)findViewById(R.id.txtnumber);
        mAirtimeAmount=(EditText)findViewById(R.id.txtAirtimeAmount);

        mOtherNumberSubmit=(Button)findViewById(R.id.btnOtherNumberSubmit);
        mOtherNumberCancel=(Button)findViewById(R.id.btnOtherNumberCancel);

        Bundle mBundle= getIntent().getExtras();
        memberNumber=mBundle.getString("memberNumber");
        mUserAccount.setText(memberNumber);


        mOtherNumberSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(getApplicationContext(),Activity_Pin_Request.class);
                Bundle mBundle = new Bundle();
                mBundle.putString(KEY_MEMBER_ACCOUNT_NUMBER, memberNumber);
                intent.putExtras(mBundle);
                startActivity(intent);
            }
        });
        mOtherNumberCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               finish();
            }
        });
    }
}
