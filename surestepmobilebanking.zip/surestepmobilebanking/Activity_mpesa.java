package com.kerioh.surestep.com.surestepmobilebanking;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by Admin on 5/31/2016.
 */
public class Activity_mpesa extends AppCompatActivity {
    Button mSaccotoMpesa,mMpesatoSacco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mpesa);
        mSaccotoMpesa=(Button)findViewById(R.id.btnMobiletoSacco);
        mMpesatoSacco=(Button)findViewById(R.id.btnSaccoToMobile);


        mSaccotoMpesa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Activity_Mpesa_Withdraw.class);
                startActivity(intent);
            }
        });
        mMpesatoSacco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Activity_Mpsesa_Deposit.class);
                startActivity(intent);
            }
        });

    }
}
