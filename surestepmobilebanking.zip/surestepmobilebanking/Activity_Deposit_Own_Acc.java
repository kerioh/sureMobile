package com.kerioh.surestep.com.surestepmobilebanking;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Admin on 6/2/2016.
 */
public class Activity_Deposit_Own_Acc extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deposit_own_acc);
    }
}
