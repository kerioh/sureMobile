package com.kerioh.surestep.com.surestepmobilebanking;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by Admin on 5/31/2016.
 */
public class Activity_Airtime_Recipient extends AppCompatActivity {

    TextView mMyself,mOtherNumber;
    public static final String KEY_MEMBER_ACCOUNT_NUMBER = "memberNumber";
    String memberNumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_airtime_recipient);

        mMyself=(TextView)findViewById(R.id.btnselfAirtime);
        mOtherNumber=(TextView)findViewById(R.id.btnotherAirtime);

        Bundle mBundle= getIntent().getExtras();
        memberNumber=mBundle.getString("memberNumber");

        mMyself.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Activity_Airtime_toSelf.class);
                Bundle mBundle = new Bundle();
                mBundle.putString(KEY_MEMBER_ACCOUNT_NUMBER, memberNumber);
                intent.putExtras(mBundle);
                startActivity(intent);

            }
        });
        mOtherNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Activity_Airtime_To_OtherNumber.class);
                Bundle mBundle = new Bundle();
                mBundle.putString(KEY_MEMBER_ACCOUNT_NUMBER, memberNumber);
                intent.putExtras(mBundle);
                startActivity(intent);
            }
        });
    }
}
