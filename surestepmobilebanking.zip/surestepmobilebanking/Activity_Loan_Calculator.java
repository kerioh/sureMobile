package com.kerioh.surestep.com.surestepmobilebanking;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.NumberFormat;
import java.util.Locale;

/**
 * Created by Admin on 5/24/2016.
 */
public class Activity_Loan_Calculator extends AppCompatActivity {

    EditText mLoanAmount, mLoanRate, mLoanDuration;
    TextView mLoanResults;
    Button mCalculate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loan_calculator);
        mLoanAmount = (EditText) findViewById(R.id.txtLoanAmount);
        mLoanRate = (EditText) findViewById(R.id.txtLoanRate);
        mLoanDuration = (EditText) findViewById(R.id.txtLoanDuration);
        mLoanResults = (TextView) findViewById(R.id.txtLoanResults);

        mCalculate = (Button) findViewById(R.id.btnGetResults);
        mCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float num1 = 0;
                float num2 = 0;
                float num3 = 0;
                float result = 0;

                // check if the fields are empty
                if (TextUtils.isEmpty(mLoanAmount.getText().toString())
                        || TextUtils.isEmpty(mLoanRate.getText().toString())
                        || TextUtils.isEmpty(mLoanDuration.getText().toString())) {
                    return;
                }

                // read EditText and fill variables with numbers
                num1 = Float.parseFloat(mLoanAmount.getText().toString());
                num2 = Float.parseFloat(mLoanRate.getText().toString());
                num3 = Float.parseFloat(mLoanDuration.getText().toString());


                result = num1 * num2 / num3 /100;
                // form the output line
                mLoanResults.setText(" Your Estimated monthly contribution will be Kshs: " + result);
            }
        });


    }
}
