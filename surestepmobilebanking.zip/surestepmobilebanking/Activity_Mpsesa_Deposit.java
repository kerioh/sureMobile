package com.kerioh.surestep.com.surestepmobilebanking;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Admin on 5/31/2016.
 */
public class Activity_Mpsesa_Deposit extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mpesa_deposit);
    }
}
