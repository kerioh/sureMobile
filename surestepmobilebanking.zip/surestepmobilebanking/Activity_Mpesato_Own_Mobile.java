package com.kerioh.surestep.com.surestepmobilebanking;

import com.kerioh.surestep.com.surestepmobilebanking.R;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
/**
 * Created by Admin on 5/31/2016.
 */
public class Activity_Mpesato_Own_Mobile extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_withdrawto_own_mobile);

    }
}
