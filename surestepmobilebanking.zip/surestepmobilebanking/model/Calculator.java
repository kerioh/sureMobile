package com.kerioh.surestep.com.surestepmobilebanking.model;

/**
 * Created by G on 4/19/2016.
 */
public class Calculator {

    private String mAmount;
    private String mFigure;


    public Calculator() {

    }

    public Calculator(String amount, String loanAmoiunt) {
        mAmount = amount;
        mFigure = loanAmoiunt;

    }

    public String getAmount() {
        return mAmount;
    }

    public void setAmount(String amount) {
        mAmount = amount;
    }

    public String getLoanFigure() {
        return mFigure;
    }

    public void setLoanFigure(String loanFigure) {
        mFigure = loanFigure;
    }


}
