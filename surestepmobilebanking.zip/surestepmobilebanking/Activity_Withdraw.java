package com.kerioh.surestep.com.surestepmobilebanking;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.EditText;
import android.widget.RadioButton;

/**
 * Created by Admin on 5/23/2016.
 */
public class Activity_Withdraw extends AppCompatActivity {
    RadioButton mSelf, mOther;
    EditText mRecipient, mAmount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_withdraw);

        mSelf = (RadioButton) findViewById(R.id.rbSelf);
        mOther = (RadioButton) findViewById(R.id.rbOther);
        mRecipient = (EditText) findViewById(R.id.txtOtherNumber);
        mAmount = (EditText) findViewById(R.id.txtWithdrawAmount);


    }
}
