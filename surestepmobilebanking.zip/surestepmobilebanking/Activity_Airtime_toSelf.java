package com.kerioh.surestep.com.surestepmobilebanking;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.kerioh.surestep.com.surestepmobilebanking.utils.AppController;
import com.kerioh.surestep.com.surestepmobilebanking.utils.CustomJsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

/**
 * Created by Admin on 5/31/2016.
 */
public class Activity_Airtime_toSelf extends AppCompatActivity {
    public static final String KEY_MEMBER_ACCOUNT_NUMBER = "memberNumber";
    final String URL = "http://62.12.113.67/mobile_app_api/loan_from_app.php";
    String memberNumber;
    TextView mUserAccount;
    EditText mAirtimeToSelfAmount;
    Button mAirtimeToSelfButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_airtime_myself);
        mUserAccount = (TextView) findViewById(R.id.lblSelfAccNo);
        mAirtimeToSelfAmount = (EditText) findViewById(R.id.txtAirtimeAmount);
        mAirtimeToSelfButton = (Button) findViewById(R.id.btnSendCash);

        Bundle mBundle = getIntent().getExtras();
        memberNumber = mBundle.getString("memberNumber");
        mUserAccount.setText(memberNumber);

        mAirtimeToSelfButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent= new Intent(getApplicationContext(),Activity_Pin_Request.class);
                Bundle mBundle = new Bundle();
                mBundle.putString(KEY_MEMBER_ACCOUNT_NUMBER, memberNumber);
                intent.putExtras(mBundle);
                startActivity(intent);
            }
        });
    }
}
